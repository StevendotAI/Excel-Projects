# Superstore Sales Dashboard

**Superstore Sales**<br/>
This project identifies the yearly performance of product categories in addition to customer acquisition.

Utilizes the following functions:<br/>
- Pivot tables to create breakdowns
- Graphing to provide visualizations
- Slicers and Timelines for interactivity
- Practical and aesthetic use of color
- Conditional formatting for dynamic highlighting
